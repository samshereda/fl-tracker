package com.example.flTrackerBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlTrackerBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlTrackerBackendApplication.class, args);
	}

}
